import React, { useState, useMemo } from 'react';
import { Plus, Search, CheckSquare, CheckCircle2, Calendar, FolderKanban } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { TaskStatus, TaskPriority } from '../types';
import { statusColors } from '../utils/formatters';

export const TasksPage: React.FC = () => {
  const { tasks, toggleTask, openCreateModal, openEditModal, searchQuery } = useApp();
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedPriority, setSelectedPriority] = useState<string>('all');
  const [localSearch, setLocalSearch] = useState<string>('');

  const filteredTasks = useMemo(() => {
    const q = (searchQuery || localSearch).toLowerCase().trim();
    return tasks.filter((t) => {
      const matchStatus =
        selectedStatus === 'all'
          ? true
          : selectedStatus === 'active'
          ? !t.completed
          : selectedStatus === 'completed'
          ? t.completed
          : t.status === selectedStatus;

      const matchPriority = selectedPriority === 'all' || t.priority === selectedPriority;

      const matchQuery =
        !q ||
        t.title.toLowerCase().includes(q) ||
        t.projectName.toLowerCase().includes(q);

      return matchStatus && matchPriority && matchQuery;
    });
  }, [tasks, selectedStatus, selectedPriority, searchQuery, localSearch]);

  const activeCount = tasks.filter((t) => !t.completed).length;
  const completedCount = tasks.filter((t) => t.completed).length;

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2.5">
            <CheckSquare size={24} className="text-[#10B981]" />
            Задачи
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Детализация этапов по проектам с контролем приоритетов
          </p>
        </div>
        <button
          onClick={() => openCreateModal('task')}
          className="flex items-center justify-center gap-2 px-4 py-2.5 bg-[#1E232A] hover:bg-[#2C333D] active:scale-[0.98] text-white text-xs sm:text-sm font-semibold rounded-xl shadow-xs transition-all min-h-[44px]"
        >
          <Plus size={16} />
          Новая задача
        </button>
      </div>

      {/* Filter bar */}
      <div className="bg-white p-3 rounded-2xl border border-slate-200/70 shadow-xs space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Status buttons */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
            <button
              onClick={() => setSelectedStatus('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                selectedStatus === 'all'
                  ? 'bg-[#1E232A] text-white'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              Все ({tasks.length})
            </button>
            <button
              onClick={() => setSelectedStatus('active')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                selectedStatus === 'active'
                  ? 'bg-[#1E232A] text-white'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              В работе ({activeCount})
            </button>
            <button
              onClick={() => setSelectedStatus('completed')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                selectedStatus === 'completed'
                  ? 'bg-[#1E232A] text-white'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              Выполненные ({completedCount})
            </button>
          </div>

          {/* Priority dropdown */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-medium">Приоритет:</span>
            <select
              value={selectedPriority}
              onChange={(e) => setSelectedPriority(e.target.value)}
              className="text-xs font-semibold bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-slate-700 focus:outline-none"
            >
              <option value="all">Любой</option>
              <option value="Срочный">Срочный</option>
              <option value="Высокий">Высокий</option>
              <option value="Средний">Средний</option>
              <option value="Низкий">Низкий</option>
            </select>
          </div>
        </div>

        {/* Local search input */}
        <div className="relative w-full">
          <Search
            size={14}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none"
          />
          <input
            type="text"
            value={localSearch}
            onChange={(e) => setLocalSearch(e.target.value)}
            placeholder="Фильтр по названию задачи или проекту..."
            className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 hover:bg-slate-100/60 focus:bg-white text-slate-900 placeholder:text-slate-400 rounded-xl border border-slate-200 focus:outline-none transition-all"
          />
        </div>
      </div>

      {/* Task List */}
      <div className="bg-white rounded-2xl border border-slate-200/70 shadow-xs divide-y divide-slate-100 overflow-hidden">
        {filteredTasks.length === 0 ? (
          <div className="p-12 text-center text-slate-400">
            <CheckCircle2 size={32} className="mx-auto mb-2 text-slate-300" />
            <div className="text-sm font-bold text-slate-700">Задачи не найдены</div>
            <p className="text-xs text-slate-400 mt-1">
              Создайте задачу или сбросьте параметры фильтрации
            </p>
          </div>
        ) : (
          filteredTasks.map((task) => {
            const priorityConfig = statusColors[task.priority] || {
              bg: 'bg-slate-100',
              text: 'text-slate-700',
            };

            return (
              <div
                key={task.id}
                className={`p-3.5 sm:p-4 hover:bg-slate-50/70 transition-colors flex items-center justify-between gap-3 ${
                  task.completed ? 'bg-slate-50/40 opacity-75' : ''
                }`}
              >
                <div className="flex items-center gap-3.5 flex-1 min-w-0">
                  {/* Complete toggle checkbox */}
                  <button
                    onClick={() => toggleTask(task.id)}
                    className={`w-6 h-6 rounded-lg border flex items-center justify-center transition-all min-w-[24px] ${
                      task.completed
                        ? 'bg-emerald-500 border-emerald-500 text-white shadow-xs'
                        : 'border-slate-300 hover:border-slate-500 bg-white'
                    }`}
                    aria-label="Завершить задачу"
                  >
                    {task.completed && <CheckCircle2 size={15} />}
                  </button>

                  <div
                    className="min-w-0 cursor-pointer flex-1"
                    onClick={() => openEditModal('task', task)}
                  >
                    <div
                      className={`text-sm font-semibold tracking-tight ${
                        task.completed ? 'line-through text-slate-400' : 'text-slate-900'
                      }`}
                    >
                      {task.title}
                    </div>
                    <div className="text-[11px] text-slate-500 font-medium flex items-center gap-2 mt-0.5">
                      <span className="flex items-center gap-1 text-slate-600 truncate">
                        <FolderKanban size={11} className="text-slate-400" />
                        {task.projectName}
                      </span>
                      <span>•</span>
                      <span className="flex items-center gap-1 text-slate-400 shrink-0">
                        <Calendar size={11} />
                        {task.deadline}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Priority & Status tag */}
                <div className="flex items-center gap-2 shrink-0">
                  <span
                    className={`text-[11px] px-2.5 py-0.5 rounded-full font-semibold border ${priorityConfig.bg}`}
                  >
                    {task.priority}
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
